package onlinetest;
import java.util.*;

public class AES {
    private static final String keytext = "000102030405060708090A0B0C0D0E0F"; 
    private static int[] key;
    private static int[] expandedKey;
    AES(){
        key = stringToAsci(keytext);
        expandedKey = expandKey(key);
    }
    
    private static final int[] RCON = {
        0x00,
        0x01, 0x02, 0x04, 0x08, 0x10,
        0x20, 0x40, 0x80, 0x1B, 0x36
    };
    private static final int[] S_BOX = {
        0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
	0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
	0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
	0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
	0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
	0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
	0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
	0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
	0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
	0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
	0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
	0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
	0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
	0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
	0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
	0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16
    };

    private static final int[] INV_S_BOX = {
        0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB,
	0x7C, 0xE3, 0x39, 0x82, 0x9B, 0x2F, 0xFF, 0x87, 0x34, 0x8E, 0x43, 0x44, 0xC4, 0xDE, 0xE9, 0xCB,
	0x54, 0x7B, 0x94, 0x32, 0xA6, 0xC2, 0x23, 0x3D, 0xEE, 0x4C, 0x95, 0x0B, 0x42, 0xFA, 0xC3, 0x4E,
	0x08, 0x2E, 0xA1, 0x66, 0x28, 0xD9, 0x24, 0xB2, 0x76, 0x5B, 0xA2, 0x49, 0x6D, 0x8B, 0xD1, 0x25,
	0x72, 0xF8, 0xF6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xD4, 0xA4, 0x5C, 0xCC, 0x5D, 0x65, 0xB6, 0x92,
	0x6C, 0x70, 0x48, 0x50, 0xFD, 0xED, 0xB9, 0xDA, 0x5E, 0x15, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84,
	0x90, 0xD8, 0xAB, 0x00, 0x8C, 0xBC, 0xD3, 0x0A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x45, 0x06,
	0xD0, 0x2C, 0x1E, 0x8F, 0xCA, 0x3F, 0x0F, 0x02, 0xC1, 0xAF, 0xBD, 0x03, 0x01, 0x13, 0x8A, 0x6B,
	0x3A, 0x91, 0x11, 0x41, 0x4F, 0x67, 0xDC, 0xEA, 0x97, 0xF2, 0xCF, 0xCE, 0xF0, 0xB4, 0xE6, 0x73,
	0x96, 0xAC, 0x74, 0x22, 0xE7, 0xAD, 0x35, 0x85, 0xE2, 0xF9, 0x37, 0xE8, 0x1C, 0x75, 0xDF, 0x6E,
	0x47, 0xF1, 0x1A, 0x71, 0x1D, 0x29, 0xC5, 0x89, 0x6F, 0xB7, 0x62, 0x0E, 0xAA, 0x18, 0xBE, 0x1B,
	0xFC, 0x56, 0x3E, 0x4B, 0xC6, 0xD2, 0x79, 0x20, 0x9A, 0xDB, 0xC0, 0xFE, 0x78, 0xCD, 0x5A, 0xF4,
	0x1F, 0xDD, 0xA8, 0x33, 0x88, 0x07, 0xC7, 0x31, 0xB1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xEC, 0x5F,
	0x60, 0x51, 0x7F, 0xA9, 0x19, 0xB5, 0x4A, 0x0D, 0x2D, 0xE5, 0x7A, 0x9F, 0x93, 0xC9, 0x9C, 0xEF,
	0xA0, 0xE0, 0x3B, 0x4D, 0xAE, 0x2A, 0xF5, 0xB0, 0xC8, 0xEB, 0xBB, 0x3C, 0x83, 0x53, 0x99, 0x61,
	0x17, 0x2B, 0x04, 0x7E, 0xBA, 0x77, 0xD6, 0x26, 0xE1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0C, 0x7D
    };
    
    
    private static int[] expandKey(int[] key) {
        int[] expandedKey = new int[176]; 

        System.arraycopy(key, 0, expandedKey, 0, 16);

        int bytesCount = 16;
        int rconIndex = 1;
        int[] temp = new int[4];

        while (bytesCount < 176) { 
            for (int i = 0; i < 4; i++) {
                temp[i] = expandedKey[bytesCount - 4 + i];
            }

            if (bytesCount % (16) == 0) {
                SubWordRotWordXOR(temp, rconIndex++);
            }

            for (int a = 0; a < 4; a++) {
                expandedKey[bytesCount] = expandedKey[bytesCount - 16] ^ temp[a];
                bytesCount++;
            }
        }

        return expandedKey;
    }
    private static int gmul(int a, int b) {
        int p = 0;
        while (a != 0 && b != 0) {
            if ((b & 1) != 0) {
                p ^= a;
            }
            if ((a & 0x80) != 0) {
                a = (a << 1) ^ 0x11B; 
            } else {
                a <<= 1;
            }
            b >>= 1;
        }
        return p;
    }
    
    private static void encSubBytes(int[] state) {
        for (int i = 0; i < 16; i++) {
            state[i] = S_BOX[state[i] & 0xFF]; 
        }
    }
    
    private static void leftShiftRows(int[] state) {
        int[] tempState = new int[16];

        tempState[0] = state[0];
        tempState[1] = state[5];
        tempState[2] = state[10];
        tempState[3] = state[15];

        tempState[4] = state[4];
        tempState[5] = state[9];
        tempState[6] = state[14];
        tempState[7] = state[3];

        tempState[8] = state[8];
        tempState[9] = state[13];
        tempState[10] = state[2];
        tempState[11] = state[7];

        tempState[12] = state[12];
        tempState[13] = state[1];
        tempState[14] = state[6];
        tempState[15] = state[11];

        System.arraycopy(tempState, 0, state, 0, 16);
    }  

    
    private static void mixColumns(int[] state) {
        int[] tempState = new int[16];
        
//        2 3 1 1
//        1 2 3 1
//        1 1 2 3
//        3 1 1 2

        for (int i = 0; i < 4; i++) {
            int col = i * 4; 
            tempState[col] = (gmul(state[col], 2) ^ gmul(state[col + 1], 3) ^ state[col + 2] ^ state[col + 3]);
            tempState[col + 1] = (state[col] ^ gmul(state[col + 1], 2) ^ gmul(state[col + 2], 3) ^ state[col + 3]);
            tempState[col + 2] = (state[col] ^ state[col + 1] ^ gmul(state[col + 2], 2) ^ gmul(state[col + 3], 3));
            tempState[col + 3] = (gmul(state[col], 3) ^ state[col + 1] ^ state[col + 2] ^ gmul(state[col + 3], 2));
        }

        System.arraycopy(tempState, 0, state, 0, 16);
    }
    
    
    private static void addRoundKey(int[] state, int[] roundKey, int round) {
        for (int i = 0; i < 16; i++) {
            state[i] ^= roundKey[round * 16 + i]; 
        }
    }

    
    
    private static void SubWordRotWordXOR(int[] tempWord, int i) {
        // RotWord
        int temp = tempWord[0];
        tempWord[0] = tempWord[1];
        tempWord[1] = tempWord[2];
        tempWord[2] = tempWord[3];
        tempWord[3] = temp;

        // Subbyte
        for (int j = 0; j < 4; j++) {
            tempWord[j] = S_BOX[tempWord[j] & 0xFF];
        }
      
        tempWord[0] ^= RCON[i];

    }
    
    private static int[] encrypt(int[] plaintext, int[] expandedKey) {
        int[] state = new int[16];
        int[] cipher = new int[16];

        System.arraycopy(plaintext, 0, state, 0, 16);

        addRoundKey(state, expandedKey, 0);
        
        for (int i = 1; i <= 9; i++) {
            encSubBytes(state);
            leftShiftRows(state);
            mixColumns(state);
            addRoundKey(state, expandedKey, i);
        }

        encSubBytes(state);
        leftShiftRows(state);
        addRoundKey(state, expandedKey, 10); 

        System.arraycopy(state, 0, cipher, 0, 16);

        return cipher;
    }
    
    
    
    
    private static void decSubBytes(int[] state) {
        for (int i = 0; i < 16; i++) {
            state[i] = INV_S_BOX[state[i] & 0xFF];
        }
    }
    
    private static void rightShiftRows(int[] state) {
        int[] tempState = new int[16];
        
        tempState[0] = state[0];
        tempState[1] = state[13];
        tempState[2] = state[10];
        tempState[3] = state[7];

        tempState[4] = state[4];
        tempState[5] = state[1];
        tempState[6] = state[14];
        tempState[7] = state[11];

        tempState[8] = state[8];
        tempState[9] = state[5];
        tempState[10] = state[2];
        tempState[11] = state[15];

        tempState[12] = state[12];
        tempState[13] = state[9];
        tempState[14] = state[6];
        tempState[15] = state[3];

        // Copy the shifted state back to the original state
        System.arraycopy(tempState, 0, state, 0, 16);
    }

    private static void inverseMixColumns(int[] state) {
        int[] tempState = new int[16];

//        14 11 13 9
//        9 14 11 13
//        13 9 14 11
//        11 13 9 14
        
        for (int i = 0; i < 4; i++) {
            int col = i * 4;
            tempState[col] = (gmul(state[col], 14) ^ gmul(state[col + 1], 11) ^ gmul(state[col + 2], 13) ^ gmul(state[col + 3], 9));
            tempState[col + 1] = (gmul(state[col], 9) ^ gmul(state[col + 1], 14) ^ gmul(state[col + 2], 11) ^ gmul(state[col + 3], 13));
            tempState[col + 2] = (gmul(state[col], 13) ^ gmul(state[col + 1], 9) ^ gmul(state[col + 2], 14) ^ gmul(state[col + 3], 11));
            tempState[col + 3] = (gmul(state[col], 11) ^ gmul(state[col + 1], 13) ^ gmul(state[col + 2], 9) ^ gmul(state[col + 3], 14));
        }

        System.arraycopy(tempState, 0, state, 0, 16);
    }

   
    
    private static int[] decrypt(int[] cipher, int[] expandedKey) {
        int[] state = new int[16];
        int[] plaintext = new int[16];
        
        System.arraycopy(cipher, 0, state, 0, 16);
        
        addRoundKey(state, expandedKey, 10);
        rightShiftRows(state);
        decSubBytes(state);
        
        for (int i = 9; i >= 1; i--) {
            addRoundKey(state, expandedKey, i);
            inverseMixColumns(state);
            rightShiftRows(state);
            decSubBytes(state);
        }
        
        addRoundKey(state, expandedKey, 0);
        
        System.arraycopy(state, 0, plaintext, 0, 16);

        return plaintext;
    }
    
    
    
    private static int[] stringToAsci(String text) {
        int n = text.length();
        int[] res = new int[n / 2];
        Map<Character, Integer> mp = new HashMap<>();
        for (int i = 0; i < 10; i++) {
            mp.put((char) (i + '0'), i);
        }
        for (int i = 0; i < 6; i++) {
            mp.put((char) (i + 'a'), i + 10);
            mp.put((char) (i + 'A'), i + 10);
        }   
        
//        System.out.println("Hexa map val:");
//        for (Map.Entry<Character, Integer> it : mp.entrySet()) {
//            System.out.println("char: " + it.getKey() + " value: " + it.getValue());
//        }
//        System.out.println("Text: "+text);
        for (int i = 0; i < n / 2; i++) {
            char c1 = text.charAt(i * 2);
            char c2 = text.charAt(i * 2 + 1);

            // Checking if the char is in map or not
            if (!mp.containsKey(c1) || !mp.containsKey(c2)) {
                throw new IllegalArgumentException("Invalid hexadecimal character in input: " + c1 + " or " + c2);
            }

            int b1 = mp.get(c1);
            int b2 = mp.get(c2);
            int value = (16 * b1 + b2) & 0xFF;
            res[i] = value;
            
//            System.out.println(c1+" "+c2+"Result: "+res[i]);
//            System.out.println(Integer.toHexString(value).toUpperCase());
        }
        return res;
    }

    private static String hexToString(int[] hex) {
//         System.out.println("Decrypted hex:");
//            for (int i = 0; i < hex.length; i++) {
//                System.out.println("Index " + i + ": " + hex[i]);
//            }
        StringBuilder res = new StringBuilder();
        Map<Integer, Character> mp = new HashMap<>();
        for (int i = 0; i < 10; i++) {
            mp.put(i, (char) (i + '0'));
        }
        for (int i = 0; i < 6; i++) {
            mp.put(i + 10, (char) (i + 'a'));
            mp.put(i + 10, (char) (i + 'A'));
        }

        for (int b : hex) {
            int x = b & 0xFF;
            char b1 = mp.get(x / 16);
            char b2 = mp.get(x % 16);
            res.append(b1).append(b2);
        }
        return res.toString();
    }
    
    private static int[] stringToInt(String text) {
        if (text.length() % 2 != 0) {
            throw new IllegalArgumentException("Input string must have an even length.");
        }

        int n = text.length();
        int[] result = new int[n / 2];
        Map<Character, Integer> hexMap = new HashMap<>();

        
        for (int i = 0; i < 10; i++) {
            hexMap.put((char) (i + '0'), i);
        }
        for (int i = 0; i < 6; i++) {
            hexMap.put((char) (i + 'a'), i + 10);
            hexMap.put((char) (i + 'A'), i + 10);
        }

//        System.out.println("Input Text: " + text);
        for (int i = 0; i < n / 2; i++) {
            char c1 = text.charAt(i * 2);
            char c2 = text.charAt(i * 2 + 1);

            if (!hexMap.containsKey(c1) || !hexMap.containsKey(c2)) {
                throw new IllegalArgumentException("Invalid hexadecimal character in input: " + c1 + " or " + c2);
            }

            int b1 = hexMap.get(c1);
            int b2 = hexMap.get(c2);
            int value = (16 * b1 + b2) & 0xFF;
            result[i] = value;

//            System.out.println("Chars: " + c1 + c2 + " -> int: " + result[i]);
        }
        return result;
    }
    private static String messageToPlaintext(String message) {
        StringBuilder hexMessage = new StringBuilder();        
        for (int i = 0; i < message.length(); i++) {
            String hexValue = String.format("%02X", (int) message.charAt(i));
            hexMessage.append(hexValue);     
//            System.out.println("For "+message.charAt(i)+" -> "+hexValue);
//            hexMessage.append(" ");
        }  
//        System.out.println("Message to plainText: "+hexMessage.toString());
        return hexMessage.toString();
    }
     
    private static String plaintextToMessage(String hexMessage) {
        StringBuilder originalMessage = new StringBuilder();
        for (int i = 0; i < hexMessage.length(); i += 2) {
            String hexValue = hexMessage.substring(i, i + 2);
            char character = (char) Integer.parseInt(hexValue, 16);
            originalMessage.append(character);
        }
        
        return originalMessage.toString();
    }
     
    public static String getEncrypted(String msz){
//        System.out.println("Hello");
        String plaintext = messageToPlaintext(msz);
        
        int n = plaintext.length();
        StringBuilder totalEnc = new StringBuilder();

        // partition of 32-character
        for (int part = 0; part < (n + 31) / 32; part++) {
            int cutoff = Math.min(n, (part + 1) * 32);
            String partString = plaintext.substring(part * 32, cutoff);

            // Padding
            while (cutoff % 32 != 0) {
                partString += "0";
                cutoff++;
            }

            int[] paddedString = stringToAsci(partString);
            int[] cipher = encrypt(paddedString, expandedKey);

       
            String res = hexToString(cipher);
            totalEnc.append(res);
        }

        System.out.println("Encrypted: " + totalEnc.toString());
        return totalEnc.toString();
     }
     
    public static String getDecrypted(String cipherText){
        StringBuilder totalDec = new StringBuilder();

        // partition
        int n = cipherText.length();
        for (int part = 0; part < (n + 31) / 32; part++) {
            int cutoff = Math.min(n, (part + 1) * 32);
            String partString = cipherText.substring(part * 32, cutoff);
            
            
            int[] hexArray = stringToInt(partString);
            int[] decrypted = decrypt(hexArray, expandedKey);
            
            
            // Convert decrypted ints to string
            String decryptedString = hexToString(decrypted);
//            System.out.println("After dec: "+decryptedString);            
            
            
            // Remove padding            
            int endIndex = 0;
            for(int i=0; i<decryptedString.length(); i+=2){
//                System.out.println(i+" "+decryptedString.charAt(i)+" "+decryptedString.charAt(i+1)+" "+endIndex);
                if(decryptedString.charAt(i)!='0' || decryptedString.charAt(i+1)!='0'){
                    endIndex = i+2;
                }
            }                
            decryptedString = decryptedString.substring(0, endIndex);
            

            totalDec.append(decryptedString);
        }
        System.out.println("Decrypted: " + totalDec.toString());
        String msz = plaintextToMessage(totalDec.toString());
        System.out.println("Decrypted: " + msz);
        return msz;
     }
}
