package onlinetest;

import java.io.*;
import java.net.Socket;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class ClientHandler extends Thread {
    final Socket com_tunnel;
    final DataInputStream inp;
    final DataOutputStream outp;
    final JTextArea jTextAreaServer;
    String msz = "";
    boolean isCheating = false;

    public ClientHandler(Socket s, DataOutputStream outp, DataInputStream inp, JTextArea jTextAreaServer) {
        this.com_tunnel = s;
        this.inp = inp;
        this.outp = outp;
        this.jTextAreaServer = jTextAreaServer;
    }

    @Override
    public void run() {
        try {
            // Cheating Detection Notification
            while (true) {
                String cheatSignal = inp.readUTF();
                if(cheatSignal.equals("close")){
                    System.out.println("Student has finished the test.");
                    outp.writeUTF("Test Completed. Closing connection.");
                    break;
                }
                else{
//                    System.out.println("Student " + cheatSignal+ "("+cheatSignal+")");
                    SwingUtilities.invokeLater(() -> jTextAreaServer.append(cheatSignal + "\n"));
            
                    jTextAreaServer.append(cheatSignal);
                }
            }
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        } finally {
            try {
                inp.close();
                outp.close();
                com_tunnel.close();
            } catch (IOException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
