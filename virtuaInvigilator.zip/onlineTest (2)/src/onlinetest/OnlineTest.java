/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package onlinetest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class OnlineTest {
    public static int numOfQuestion = 0, teacher_id=1, test_id=1, totalMarks=0;
    public static int student_id=11, student_test_id=1, questionInd = 0, quesLength=0, totalObtainedMarks=0;
    public static String startTime, endTime, studentJoinTime= "";
    public static List<Map<String, Object>> questionData = new ArrayList<>();
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        LandingPage mainMenu=new LandingPage();
        mainMenu.setVisible(true);
        mainMenu.pack();
        mainMenu.setLocationRelativeTo(null);
        
        AES obj = new AES();
    }
    
    
    
    
//    public static void server() throws IOException{
//        ServerSocket handshake = new ServerSocket(5000);
//            System.out.println("Server is running. Waiting for clients...");
//
//        int maxClients = 5;
//        int clientCount = 0;
//
//        while (clientCount < maxClients) {
//            Socket com_socket = handshake.accept();
//            System.out.println("A client connected: " + com_socket);
//
//            DataOutputStream out = new DataOutputStream(com_socket.getOutputStream());
//            DataInputStream in = new DataInputStream(com_socket.getInputStream());
//
//            System.out.println("Assigning a new thread for the client...");
//            Thread clientThread = new ClientHandler(com_socket, out, in);
//            clientThread.start();
//
//            clientCount++;
//        }
//        System.out.println("Client limit exceeded. Server stopping.");
//        handshake.close();
//    }
    
}
